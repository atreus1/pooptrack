angular.module('starter.services', [])

.service('LoginService', function($q) {
  
});